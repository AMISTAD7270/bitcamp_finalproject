package com.vam.service;

import com.vam.model.CreatorVO;

public interface CreatorService {
	
	/* 작가등록 */
	public void creatorEnroll(CreatorVO creator) throws Exception;

}
