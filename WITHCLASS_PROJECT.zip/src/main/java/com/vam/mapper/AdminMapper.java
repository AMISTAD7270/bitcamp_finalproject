package com.vam.mapper;

import java.util.List;

import com.vam.model.CateVO;
import com.vam.model.EclassVO;

public interface AdminMapper {


}
